package com.example.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.R

val PlusJakartaSansFamily = FontFamily(
  Font(R.font.plus_jakarta_sans, FontWeight.Normal),
  Font(R.font.plus_jakarta_sans, FontWeight.Medium),
  Font(R.font.plus_jakarta_sans, FontWeight.SemiBold),
  Font(R.font.plus_jakarta_sans, FontWeight.Bold)
)

val CairoFontFamily = FontFamily(
  Font(R.font.cairo, FontWeight.Normal),
  Font(R.font.cairo, FontWeight.Medium),
  Font(R.font.cairo, FontWeight.SemiBold),
  Font(R.font.cairo, FontWeight.Bold)
)

fun getTaskoraTypography(isArabic: Boolean): Typography {
  val family = if (isArabic) CairoFontFamily else PlusJakartaSansFamily

  return Typography(
    displayLarge = TextStyle(
      fontFamily = family,
      fontWeight = FontWeight.Bold,
      fontSize = 32.sp,
      lineHeight = 40.sp,
      letterSpacing = (-0.5).sp
    ),
    displayMedium = TextStyle(
      fontFamily = family,
      fontWeight = FontWeight.Bold,
      fontSize = 28.sp,
      lineHeight = 36.sp,
      letterSpacing = (-0.25).sp
    ),
    headlineLarge = TextStyle(
      fontFamily = family,
      fontWeight = FontWeight.SemiBold,
      fontSize = 24.sp,
      lineHeight = 32.sp
    ),
    headlineMedium = TextStyle(
      fontFamily = family,
      fontWeight = FontWeight.SemiBold,
      fontSize = 20.sp,
      lineHeight = 28.sp
    ),
    headlineSmall = TextStyle(
      fontFamily = family,
      fontWeight = FontWeight.Medium,
      fontSize = 18.sp,
      lineHeight = 24.sp
    ),
    titleLarge = TextStyle(
      fontFamily = family,
      fontWeight = FontWeight.SemiBold,
      fontSize = 16.sp,
      lineHeight = 24.sp
    ),
    titleMedium = TextStyle(
      fontFamily = family,
      fontWeight = FontWeight.Medium,
      fontSize = 14.sp,
      lineHeight = 20.sp
    ),
    titleSmall = TextStyle(
      fontFamily = family,
      fontWeight = FontWeight.Medium,
      fontSize = 12.sp,
      lineHeight = 16.sp
    ),
    bodyLarge = TextStyle(
      fontFamily = family,
      fontWeight = FontWeight.Normal,
      fontSize = 15.sp,
      lineHeight = 22.sp
    ),
    bodyMedium = TextStyle(
      fontFamily = family,
      fontWeight = FontWeight.Normal,
      fontSize = 13.sp,
      lineHeight = 18.sp
    ),
    bodySmall = TextStyle(
      fontFamily = family,
      fontWeight = FontWeight.Normal,
      fontSize = 11.sp,
      lineHeight = 16.sp
    ),
    labelLarge = TextStyle(
      fontFamily = family,
      fontWeight = FontWeight.SemiBold,
      fontSize = 13.sp,
      lineHeight = 18.sp
    ),
    labelMedium = TextStyle(
      fontFamily = family,
      fontWeight = FontWeight.Medium,
      fontSize = 11.sp,
      lineHeight = 16.sp
    ),
    labelSmall = TextStyle(
      fontFamily = family,
      fontWeight = FontWeight.Medium,
      fontSize = 10.sp,
      lineHeight = 14.sp
    )
  )
}

val Typography = getTaskoraTypography(false)
